<?php /* Smarty version Smarty-3.1.8, created on 2013-03-13 03:30:18
         compiled from "F:\LapTrinhWeb\wamp\www\lofworks\prestashop\admin123/themes/default\template\helpers\list\list.tpl" */ ?>
<?php /*%%SmartyHeaderCode:901651402b0a28c589-66120519%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '16e5932f0278854db8b5efb83cdb4a9a28e2c578' => 
    array (
      0 => 'F:\\LapTrinhWeb\\wamp\\www\\lofworks\\prestashop\\admin123/themes/default\\template\\helpers\\list\\list.tpl',
      1 => 1356941956,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '901651402b0a28c589-66120519',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'header' => 0,
    'content' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_51402b0a2e3617_00742206',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51402b0a2e3617_00742206')) {function content_51402b0a2e3617_00742206($_smarty_tpl) {?>
<?php echo $_smarty_tpl->tpl_vars['header']->value;?>

<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>

<?php }} ?>