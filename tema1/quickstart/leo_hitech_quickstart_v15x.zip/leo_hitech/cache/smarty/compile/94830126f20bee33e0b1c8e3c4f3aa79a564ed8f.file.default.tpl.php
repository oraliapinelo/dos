<?php /* Smarty version Smarty-3.1.8, created on 2013-03-09 02:59:52
         compiled from "F:\LapTrinhWeb\wamp\www\lofworks\leo_hitech_new\prestashop\modules\leocamera\themes\default\default.tpl" */ ?>
<?php /*%%SmartyHeaderCode:32556513aebf83ec9c9-19118790%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '94830126f20bee33e0b1c8e3c4f3aa79a564ed8f' => 
    array (
      0 => 'F:\\LapTrinhWeb\\wamp\\www\\lofworks\\leo_hitech_new\\prestashop\\modules\\leocamera\\themes\\default\\default.tpl',
      1 => 1357801788,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '32556513aebf83ec9c9-19118790',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'leocamera' => 0,
    'leocamera_slides' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_513aebf857afb3_99443062',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_513aebf857afb3_99443062')) {function content_513aebf857afb3_99443062($_smarty_tpl) {?><div class="leocamera_container" style="width:100%;">
    <div id="leo-camera" class="camera_wrap <?php echo $_smarty_tpl->tpl_vars['leocamera']->value['theme'];?>
">
        <?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['leocamera_slides']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
            <div data-thumb="<?php echo $_smarty_tpl->tpl_vars['item']->value['thumbnail'];?>
" data-src="<?php echo $_smarty_tpl->tpl_vars['item']->value['mainimage'];?>
" >
                <?php if ($_smarty_tpl->tpl_vars['item']->value['title']&&$_smarty_tpl->tpl_vars['leocamera']->value['show_desc']){?>                            
                    <div class="camera_caption fadeFromBottom" >             
                        <div class="leo_camera_title" >
                            <?php if ($_smarty_tpl->tpl_vars['leocamera']->value['show_title']){?>
                                <a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['url'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['title'];?>
</a>
                            <?php }?>                            
                        </div>
						<div class="leo_camara_desc">
							<?php echo $_smarty_tpl->tpl_vars['item']->value['description'];?>

						</div>
                    </div>
                <?php }?>
            </div>
        <?php } ?>    
    </div>
</div><?php }} ?>