<?php /* Smarty version Smarty-3.1.8, created on 2013-03-12 21:45:20
         compiled from "F:\LapTrinhWeb\wamp\www\lofworks\prestashop\themes\leohite\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:22630513fda3089f313-94923087%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5d989602503c5cea8dd033a3ed57a165f19df498' => 
    array (
      0 => 'F:\\LapTrinhWeb\\wamp\\www\\lofworks\\prestashop\\themes\\leohite\\index.tpl',
      1 => 1356941956,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '22630513fda3089f313-94923087',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'HOOK_HOME' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_513fda308ea1a9_78067055',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_513fda308ea1a9_78067055')) {function content_513fda308ea1a9_78067055($_smarty_tpl) {?>

<?php echo $_smarty_tpl->tpl_vars['HOOK_HOME']->value;?>

<?php }} ?>