<?php /* Smarty version Smarty-3.1.8, created on 2013-03-07 02:57:57
         compiled from "F:\LapTrinhWeb\wamp\www\lofworks\leo_hitech_new\prestashop\admin123\themes\default\template\content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:31951384885c112c3-49991660%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '78fba29cb4f7da066b11bcd8def493d807a4a525' => 
    array (
      0 => 'F:\\LapTrinhWeb\\wamp\\www\\lofworks\\leo_hitech_new\\prestashop\\admin123\\themes\\default\\template\\content.tpl',
      1 => 1356941954,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '31951384885c112c3-49991660',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_51384885ce76a3_38281526',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51384885ce76a3_38281526')) {function content_51384885ce76a3_38281526($_smarty_tpl) {?>

<?php if (isset($_smarty_tpl->tpl_vars['content']->value)){?>
	<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

<?php }?>
<?php }} ?>