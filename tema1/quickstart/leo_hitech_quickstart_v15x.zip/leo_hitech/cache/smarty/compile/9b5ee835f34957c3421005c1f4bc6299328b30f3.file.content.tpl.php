<?php /* Smarty version Smarty-3.1.8, created on 2013-03-12 22:11:37
         compiled from "F:\LapTrinhWeb\wamp\www\lofworks\prestashop\admin123\themes\default\template\content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:28725513fe059bda983-29101173%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9b5ee835f34957c3421005c1f4bc6299328b30f3' => 
    array (
      0 => 'F:\\LapTrinhWeb\\wamp\\www\\lofworks\\prestashop\\admin123\\themes\\default\\template\\content.tpl',
      1 => 1356941954,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '28725513fe059bda983-29101173',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_513fe059cae997_56741697',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_513fe059cae997_56741697')) {function content_513fe059cae997_56741697($_smarty_tpl) {?>

<?php if (isset($_smarty_tpl->tpl_vars['content']->value)){?>
	<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

<?php }?>
<?php }} ?>