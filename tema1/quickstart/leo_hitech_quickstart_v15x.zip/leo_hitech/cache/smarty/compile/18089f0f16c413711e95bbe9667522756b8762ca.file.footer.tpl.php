<?php /* Smarty version Smarty-3.1.8, created on 2013-03-12 21:45:20
         compiled from "F:\LapTrinhWeb\wamp\www\lofworks\prestashop\themes\leohite\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4093513fda30d56b38-18323158%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '18089f0f16c413711e95bbe9667522756b8762ca' => 
    array (
      0 => 'F:\\LapTrinhWeb\\wamp\\www\\lofworks\\prestashop\\themes\\leohite\\footer.tpl',
      1 => 1362990101,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4093513fda30d56b38-18323158',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'content_only' => 0,
    'HOOK_RIGHT_COLUMN' => 0,
    'HOOK_FOOTER' => 0,
    'LEO_PANELTOOL' => 0,
    'LEO_PATTERN' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_513fda30dc92b7_68237460',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_513fda30dc92b7_68237460')) {function content_513fda30dc92b7_68237460($_smarty_tpl) {?>

								<?php if (!$_smarty_tpl->tpl_vars['content_only']->value){?>
								</div>
							</div>

							<!-- Right -->
							<div id="leo-rightcol" class="column">
								<?php echo $_smarty_tpl->tpl_vars['HOOK_RIGHT_COLUMN']->value;?>

							</div>
						</div>
					</div>
			</div>
			<div id="footer" class="wrap">
				<div class="leo-wrapper">
						<!-- Footer -->
						<?php echo $_smarty_tpl->tpl_vars['HOOK_FOOTER']->value;?>

				</div>
			</div>        
			<?php }?>
			   
			<?php if ($_smarty_tpl->tpl_vars['LEO_PANELTOOL']->value){?>
				<?php echo $_smarty_tpl->getSubTemplate (($_smarty_tpl->tpl_vars['tpl_dir']->value)."./info/paneltool.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

			<?php }?>
		</div>
		<script type="text/javascript">
			var classBody = "<?php echo $_smarty_tpl->tpl_vars['LEO_PATTERN']->value;?>
";
			$("body").addClass( classBody.replace(/\.\w+$/,"")  );
		</script>
	</body>
</html><?php }} ?>