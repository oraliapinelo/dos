<?php /* Smarty version Smarty-3.1.8, created on 2013-03-07 02:57:58
         compiled from "F:\LapTrinhWeb\wamp\www\lofworks\leo_hitech_new\prestashop\modules\lofnewproduct\tmpl\default\default.tpl" */ ?>
<?php /*%%SmartyHeaderCode:61651384886effbb2-47681732%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '23b3120eb819f9501de4b31f8baac3acaa282dec' => 
    array (
      0 => 'F:\\LapTrinhWeb\\wamp\\www\\lofworks\\leo_hitech_new\\prestashop\\modules\\lofnewproduct\\tmpl\\default\\default.tpl',
      1 => 1357377334,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '61651384886effbb2-47681732',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'theme' => 0,
    'moduleWidth' => 0,
    'moduleHeight' => 0,
    'moduleId' => 0,
    'listNews' => 0,
    'item' => 0,
    'show_date' => 0,
    'show_price' => 0,
    'priceSpecial' => 0,
    'show_title' => 0,
    'show_desc' => 0,
    'site_url' => 0,
    'token' => 0,
    'show_button' => 0,
    'show_pager' => 0,
    'auto_play' => 0,
    'slide_width' => 0,
    'slide_height' => 0,
    'scroll_items' => 0,
    'limit_cols' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5138488729efe4_15329295',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5138488729efe4_15329295')) {function content_5138488729efe4_15329295($_smarty_tpl) {?><div class="clearfix clear clr"></div>
<div class="lof-newproduct <?php echo $_smarty_tpl->tpl_vars['theme']->value;?>
" style="width:<?php echo $_smarty_tpl->tpl_vars['moduleWidth']->value;?>
;height:<?php echo $_smarty_tpl->tpl_vars['moduleHeight']->value;?>
">
	<section class="newproduct-widget">
		<header>
			<h3 class="newproduct-title"><?php echo smartyTranslate(array('s'=>'News Product','mod'=>'lofnewproduct'),$_smarty_tpl);?>
</h3>
		</header>
		<div class="list-newproduct responsive">
			<ul id="lofnewproduct-<?php echo $_smarty_tpl->tpl_vars['moduleId']->value;?>
" class="newproduct-news clearfix">
				<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['listNews']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>    
				<li>
					<article>
						<div class="newproduct-item box-hover clearfix">
							<div class="video-thumb">
								<img class="responsive-img" src="<?php echo $_smarty_tpl->tpl_vars['item']->value['mainImge'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
"/>
							</div>
							<div class="entry-content">
								<?php if ($_smarty_tpl->tpl_vars['show_date']->value=='1'){?><div class="entry-date"><?php echo $_smarty_tpl->tpl_vars['item']->value['dateAdd'];?>
</div><?php }?>
								<?php if ($_smarty_tpl->tpl_vars['show_price']->value=='1'){?><div class="entry-price"><?php echo $_smarty_tpl->tpl_vars['item']->value['price'];?>
</div><?php }?>
								<?php if ((($_smarty_tpl->tpl_vars['item']->value['reduction'])!=($_smarty_tpl->tpl_vars['item']->value['price']))&&($_smarty_tpl->tpl_vars['priceSpecial']->value=='1')){?>
								<div class="entry-price-discount"><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['displayWtPrice'][0][0]->displayWtPrice(array('p'=>$_smarty_tpl->tpl_vars['item']->value['price_without_reduction']),$_smarty_tpl);?>
</div>
								<?php }?>
								<?php if ($_smarty_tpl->tpl_vars['show_title']->value=='1'){?>
								<h4 class="entry-title">
									<a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</a>
								</h4>
								<?php }?>
								<?php if ($_smarty_tpl->tpl_vars['show_desc']->value=='1'){?><p><?php echo $_smarty_tpl->tpl_vars['item']->value['description'];?>
</p><?php }?>
								<a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['link'];?>
"><?php echo smartyTranslate(array('s'=>'Detail','mod'=>'lofnewproduct'),$_smarty_tpl);?>
</a>
								<?php if ((($_smarty_tpl->tpl_vars['item']->value['quantity']>0||$_smarty_tpl->tpl_vars['item']->value['allow_oosp']))){?>
								<a class="lof-add-cart ajax_add_to_cart_button" rel="ajax_id_product_<?php echo $_smarty_tpl->tpl_vars['item']->value['id_product'];?>
" href="<?php echo $_smarty_tpl->tpl_vars['site_url']->value;?>
cart.php?add&amp;id_product=<?php echo $_smarty_tpl->tpl_vars['item']->value['id_product'];?>
&amp;token=<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
"><span><?php echo smartyTranslate(array('s'=>'Add to cart','mod'=>'lofnewproduct'),$_smarty_tpl);?>
</span></a>
								<?php }else{ ?>
									<span class="lof-add-cart"><?php echo smartyTranslate(array('s'=>'Add to cart','mod'=>'lofnewproduct'),$_smarty_tpl);?>
</span></a>
								<?php }?>
							</div>
						</div>
					</article>				
				</li>
				<?php } ?>
			</ul>		
			<div class="clear"></div>
			<?php if ($_smarty_tpl->tpl_vars['show_button']->value=='1'){?>
			<div class="newproduct-nav">
				<a id="lofprev-<?php echo $_smarty_tpl->tpl_vars['moduleId']->value;?>
" class="prev" href="#">&nbsp;</a>
				<a id="lofnext-<?php echo $_smarty_tpl->tpl_vars['moduleId']->value;?>
" class="next" href="#">&nbsp;</a>
			</div><?php }?>
			<?php if ($_smarty_tpl->tpl_vars['show_pager']->value=='1'){?><div id="lofpager-<?php echo $_smarty_tpl->tpl_vars['moduleId']->value;?>
" class="lof-pager"></div><?php }?>
		</div>
	</section>
</div>
<script type="text/javascript">
// <![CDATA[
			$('#lofnewproduct-<?php echo $_smarty_tpl->tpl_vars['moduleId']->value;?>
').carouFredSel({
				responsive:true,
				prev: '#lofprev-<?php echo $_smarty_tpl->tpl_vars['moduleId']->value;?>
',
				next: '#lofnext-<?php echo $_smarty_tpl->tpl_vars['moduleId']->value;?>
',
				pagination: "#lofpager-<?php echo $_smarty_tpl->tpl_vars['moduleId']->value;?>
",
				auto: <?php echo $_smarty_tpl->tpl_vars['auto_play']->value;?>
,
				width: <?php echo $_smarty_tpl->tpl_vars['slide_width']->value;?>
,
				height: <?php echo $_smarty_tpl->tpl_vars['slide_height']->value;?>
,
				scroll: <?php echo $_smarty_tpl->tpl_vars['scroll_items']->value;?>
,
				items:{
					width:200,
					visible:{
						min:1,
						max:<?php echo $_smarty_tpl->tpl_vars['limit_cols']->value;?>

					}
				}
			});	

// ]]>
</script>  
<?php }} ?>