<?php /* Smarty version Smarty-3.1.8, created on 2013-03-12 21:45:14
         compiled from "F:\LapTrinhWeb\wamp\www\lofworks\prestashop\modules\blockadvertising\blockadvertising.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3226513fda2a0e7777-47218812%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '76fe85d29e8e382fe7f2589d81ac7afd26a9fe46' => 
    array (
      0 => 'F:\\LapTrinhWeb\\wamp\\www\\lofworks\\prestashop\\modules\\blockadvertising\\blockadvertising.tpl',
      1 => 1356941956,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3226513fda2a0e7777-47218812',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'adv_link' => 0,
    'adv_title' => 0,
    'image' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_513fda2a137189_01728689',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_513fda2a137189_01728689')) {function content_513fda2a137189_01728689($_smarty_tpl) {?>

<!-- MODULE Block advertising -->
<div class="advertising_block">
	<a href="<?php echo $_smarty_tpl->tpl_vars['adv_link']->value;?>
" title="<?php echo $_smarty_tpl->tpl_vars['adv_title']->value;?>
"><img src="<?php echo $_smarty_tpl->tpl_vars['image']->value;?>
" alt="<?php echo $_smarty_tpl->tpl_vars['adv_title']->value;?>
" title="<?php echo $_smarty_tpl->tpl_vars['adv_title']->value;?>
" width="155"  height="163" /></a>
</div>
<!-- /MODULE Block advertising -->
<?php }} ?>